sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/tatasteel/YMM_MAT_RCON2/model/formatter"
], function (Controller, JSONModel, formatter) {
	"use strict";
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/");
	//var oRouter;
	return Controller.extend("com.tatasteel.YMM_MAT_RCON2.controller.Home", {
		formatter: formatter,
		onBeforeRendering: function () {
			var that = this;
			oModel.read("/FreeOrderSet", {
				success: function (oData, response) {
					var freeOrderTable = that.getView().byId("emplist");
					var jsonModel = new JSONModel();
					jsonModel.setData({
						freeOrderSet: oData.results
					});
					freeOrderTable.setModel(jsonModel);
				}
			});
		}
	});
});