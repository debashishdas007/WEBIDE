/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"com/tatasteel/YMM_MAT_RCON2/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/tatasteel/YMM_MAT_RCON2/test/integration/pages/Home",
	"com/tatasteel/YMM_MAT_RCON2/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.tatasteel.YMM_MAT_RCON2.view.",
		autoWait: true
	});
});