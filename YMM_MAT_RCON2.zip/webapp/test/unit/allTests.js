sap.ui.define([
	"com/tatasteel/YMM_MAT_RCON2/test/unit/controller/Home.controller"
], function () {
	"use strict";
});