sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/UIComponent",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/m/MessageBox"
], function (Controller, JSONModel, UIComponent, MessagePopover, MessagePopoverItem, MessageBox) {
	"use strict";

	return Controller.extend("com.tatasteel.ZMM_MATRCON.controller.BaseController", {
		// just this.getRouter() ...
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},
		// just this.getModel() ...
		getModel: function (sName) {
			return this.getView().getModel(sName);

		},
		// just this.setModel() ...
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},
		// just this.getResoureBundle() ... 
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		openMessagePopover: function (msgArr, oControl) {
			var oMessageTemplate = new MessagePopoverItem({
				type: "{type}",
				title: "{title}",
				description: "{description}",
				subtitle: "{subtitle}",
				counter: "{counter}",
				link: ""
			});
			var oMessagePopover = new MessagePopover({
				items: {
					path: "/",
					template: oMessageTemplate
				}
			});

			var oModel = new JSONModel();
			oModel.setData(msgArr);
			oMessagePopover.setModel(oModel);
			oMessagePopover.openBy(oControl);

		},
		openMessageBox: function () {
			return sap.m.MessageBox;
		}

	});

});