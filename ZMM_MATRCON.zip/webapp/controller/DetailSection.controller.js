sap.ui.define([
	"sap/ui/core/Fragment",
	"com/tatasteel/ZMM_MATRCON/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessagePopoverItem",
	"sap/m/MessagePopover",
	"com/tatasteel/ZMM_MATRCON/model/formatter",
	"com/tatasteel/ZMM_MATRCON/utils/preview"
], function (Fragment, BaseController, History, JSONModel, MessageBox, MessagePopoverItem, MessagePopover, formatter, preview) {
	"use strict";
	var oRouter;
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/");
	var openMaterialNoFragment = "";
	var batchData = [];
	var formData = [];
	var detailsTableRecords = null;
	var requesterId = "";

	return BaseController.extend("com.tatasteel.ZMM_MATRCON.controller.DetailSection", {
		formatter: formatter,
		preview: preview,
		onInit: function () {
			sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("DetailSection").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			this.clearAllControl();
			sap.ui.getCore().setModel({}, "fragmentModel");
			var jobPeriodYear = oEvent.getParameter("arguments").jobPeriodYear; // Get Job and Year from URL
			var firstDate = new Date(jobPeriodYear.split("-")[1], jobPeriodYear.split("-")[0] - 1, 1);
			var lastDay = new Date(jobPeriodYear.split("-")[1], jobPeriodYear.split("-")[0], 0);
			this.getView().byId("firstDate").setText(this.setDateDoubleDigit(firstDate.getDate()) + "." + this.setDateDoubleDigit((firstDate.getMonth() +
				1)) + "." + firstDate.getFullYear());
			this.getView().byId("lastDate").setText(this.setDateDoubleDigit(lastDay.getDate()) + "." + this.setDateDoubleDigit((lastDay.getMonth() +
				1)) + "." + lastDay.getFullYear());
			this.orderNo = oEvent.getParameter("arguments").orderNo;
			this.jobPeriod = Number(jobPeriodYear.split("-")[0]);
			this.jobYear = jobPeriodYear.split("-")[1];
			this.vendorCode = oEvent.getParameter("arguments").vCode;
			this.requesterId = (oEvent.getParameter("arguments").rqId !== "null" ? oEvent.getParameter("arguments").rqId : "" );
			var filters = [this._createFilter("orderNo", oEvent.getParameter("arguments").orderNo),
				this._createFilter("jobPeriod", jobPeriodYear.split("-")[0]),
				this._createFilter("jobYear", jobPeriodYear.split("-")[1]),
				this._createFilter("vendorCode", this.vendorCode),
				this._createFilter("requesterId", this.requesterId)
			];

			var that = this;
			this.getView().byId("detailTable").setBusy(true);

			oModel.read("/DetailSectionSet", {
				filters: filters,
				success: function (oData, response) {
					batchData = [];
					formData = [];
					var detailTable = that.getView().byId("detailTable");
					var jsonModel = new JSONModel();
					detailsTableRecords = oData.results;
					jsonModel.setData({
						detailOrderSet: oData.results
					});
					detailTable.setModel(null);
					detailTable.setModel(jsonModel);
					detailTable.setBusy(false);
					if (detailsTableRecords.length > 0) {
						requesterId = detailsTableRecords[0].requesterId;
						var jsonModel2 = new JSONModel(detailsTableRecords[0]);
						jsonModel2.setData(detailsTableRecords[0]);
						//that.getView().byId("headerSection").setModel(jsonModel2, "headerSection");
						that.getView().setModel(jsonModel2, "headerSection");
						if (detailsTableRecords[0].status === "APPROVED" || detailsTableRecords[0].status === "PENDING") {
							that.getView().byId("detailSubmit").setEnabled(false);
							that.byId("formPreview").setVisible(false);
							that.byId("formPdf").setVisible(true);
						} else if (detailsTableRecords[0].status === "REJECTED") {
							that.getView().byId("detailSubmit").setEnabled(true);
							that.byId("formPreview").setVisible(true);
							that.byId("formPdf").setVisible(true);
						} else {
							that.getView().byId("detailSubmit").setEnabled(true);
							that.byId("formPreview").setVisible(true);
							that.byId("formPdf").setVisible(false);
						}
					}

				},
				error: function (oData, response) {
					that.getView().byId("detailTable").setBusy(false);
					that.getView().byId("detailTable").removeAllItems();
					that.openMessageBox().error(JSON.parse(oData.responseText).error.message.value);
				}
			});
		},
		setDateDoubleDigit: function (param) {
			if (param.toString().length === 1) {
				return (0 + param.toString()).trim();
			}
			return param.toString().trim();
		},
		validateDate: function (oEvent) {
			var firstDate = this.getView().byId("firstDate").getText().split(".");
			var currDate = new Date();
			var userSelDate = oEvent.getSource().getDateValue();
			var jobStartDate = new Date(firstDate[1] + "." + firstDate[0] + "." + firstDate[2]);
			// Checking Date Month and Year
			/* eslint-disable */
			currDate.setHours(0, 0, 0, 0);
			userSelDate.setHours(0, 0, 0, 0);
			jobStartDate.setHours(0, 0, 0, 0);

			if (currDate.getTime() < userSelDate.getTime()) {
				this.getView().byId("invoiceDate").setDateValue();
				this.openMessageBox().error("Invoice date cannot be future date");
			}

			if (userSelDate.getTime() < jobStartDate.getTime()) {
				this.getView().byId("invoiceDate").setDateValue();
				this.openMessageBox().error("Invoice date cannot be less than Job start date");
			}
			/* eslint-enable */

		},
		openFormFragment: function (event) {
			var that = this;
			var errors = 0;
			var ids = (
				"invoiceNo invoiceDate vendorRepresentative projManNo relToPlEqp otherEquipment"
			).split(" ");
			jQuery.each(ids, function (i, oInput) {
				if (that._validate(oInput)) {
					//data[oInput] = that.getView().byId(oInput).getValue().trim();
				} else {
					errors = errors + 1;
				}
			});
			if (errors > 0) {
				sap.m.MessageBox.error("Please input all the fields");
				return false;
			}

			sap.ui.core.BusyIndicator.show(5);
			openMaterialNoFragment = "";
			openMaterialNoFragment = event.getSource().getBindingContext().getProperty("materialNo"); // Catch the Material Number
			this.UOM = event.getSource().getBindingContext().getProperty("UOM");
			this.segment = event.getSource().getBindingContext().getProperty("segment");
			this.orderNo = event.getSource().getBindingContext().getProperty("orderNo");
			this.materialNo = event.getSource().getBindingContext().getProperty("materialNo");
			this.requesterId = event.getSource().getBindingContext().getObject().requesterId;
			this.btnEvent = event.getSource();
			batchData[this.materialNo] = {};

			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.tatasteel.ZMM_MATRCON.fragments.ManualInput",
					this
				).addStyleClass("fragMentHeader");
				this.getView().addDependent(this._dialog);
			}

			this.byId("fragmentHeader").setModel(new JSONModel(event.getSource().getBindingContext().getObject()), "tableData");
			var that = this;
			sap.ui.core.BusyIndicator.show();
			oModel.read("/CumulativeQtySet(orderNo='" + this.orderNo + "',jobPeriod='" + this.jobPeriod + "',jobYear='" + this.jobYear +
				"',materialNo='" + openMaterialNoFragment + "',requesterId='" + this.requesterId + "')", {
					success: function (oData, response) {
						sap.ui.getCore().setModel({}, "fragmentModel");
						delete oData.__metadata;
						//sap.ui.getCore().setModel(oData, "fragmentModel");
						var jsonModel = new JSONModel();
						oData.orderNo = that.orderNo;
						oData.materialNo = that.materialNo;
						oData.segment = that.segment;
						oData.UOM = that.UOM;

						jsonModel.setData(oData);
						sap.ui.getCore().setModel({}, "fragmentModel");
						sap.ui.getCore().setModel(jsonModel, "fragmentModel");
						that._dialog.setModel(sap.ui.getCore().getModel("fragmentModel"));
						sap.ui.core.BusyIndicator.hide();
						that._dialog.open();
					},
					error: function (oData, response) {
						/* eslint-disable */
						console.log("Error Because of Data not Found in YMPIT_MAT_RCON Table");
						/* eslint-enable */
						that._dialog.open();

					}
				});

		},
		upDateModel: function (oEvent) {
			var t = sap.ui.getCore().getModel("fragmentModel");
			t.setProperty("/" + oEvent.getSource().getId().split("--")[1], parseFloat(oEvent.getParameters().value).toFixed(3));
			sap.ui.getCore().getModel("fragmentModel").refresh(true);
			this.setfragmentData(sap.ui.getCore().getModel("fragmentModel").getData());
		},
		setfragmentData: function (data) {
			var jsonModel = new JSONModel();
			data.conQtyTot = (parseFloat(data.conQtyPrevRec) + parseFloat(data.conQtyBill)).toFixed(3).toString().trim(); // (F=D+E)
			data.unAccWtgTot = (parseFloat(data.unAccWtgPreRec) + parseFloat(data.unAccWtgBill)).toFixed(3).toString().trim(); // (I=G+H)
			data.accWtgQtyTot = (parseFloat(data.accWtgQtyPreRec) + parseFloat(data.accWtgQtyBill)).toFixed(3).toString().trim(); // (L=J+K)
			data.balanceQty = (parseFloat(data.netIssueQuantity) - parseFloat(data.conQtyTot) - parseFloat(data.unAccWtgTot) - parseFloat(data.accWtgQtyTot))
				.toFixed(3).toString().trim(); // (M=C-F-I-L)
			jsonModel.setData(data);
			sap.ui.getCore().setModel({}, "fragmentModel");
			sap.ui.getCore().setModel(jsonModel, "fragmentModel");
			if (typeof this._dialog !== "undefined") {
				this._dialog.setModel(sap.ui.getCore().getModel("fragmentModel"));
			}
			batchData[data.materialNo] = data;

		},
		/* eslint-disable */
		handleManulaInputSubmit: function (oEvent) {
			this.setfragmentData(sap.ui.getCore().getModel("fragmentModel").getData());
			var data = {};
			var that = this;
			var errors = 0;
			var ids = (
				"invoiceNo invoiceDate vendorRepresentative projManNo relToPlEqp otherEquipment freeIssueIMSection nonFreeIssueIMSection netIssueQuantity conQtyPrevRec conQtyBill conQtyTot unAccWtgPreRec unAccWtgBill unAccWtgTot accWtgQtyPreRec accWtgQtyBill balanceQty"
			).split(" ");
			jQuery.each(ids, function (i, oInput) {
				if (that._validate(oInput)) {
					data[oInput] = that.getView().byId(oInput).getValue().trim();
				} else {
					errors = errors + 1;
				}
			});
			if (errors > 0) {
				sap.m.MessageBox.error("Please input all the fields");
				this._dialog.close();
			} else if (parseFloat(batchData[openMaterialNoFragment].balanceQty) < 0.00) {
				delete batchData[openMaterialNoFragment];
				this.btnEvent.setIcon("sap-icon://action-settings");
				this.openMessageBox().error("Balance Quantity should not be in Negative \n Either No Request will be Submitted");
				return false;
			} else {
				var t = new Date(this.getView().byId("invoiceDate").getDateValue().getTime() + 86400000);
				batchData[openMaterialNoFragment].invoiceNo = data.invoiceNo;
				batchData[openMaterialNoFragment].vendorRepresentative = data.vendorRepresentative;
				batchData[openMaterialNoFragment].vendorCode = this.vendorCode;
				batchData[openMaterialNoFragment].projManNo = data.projManNo;
				batchData[openMaterialNoFragment].relToPlEqp = data.relToPlEqp;
				batchData[openMaterialNoFragment].otherEquipment = data.otherEquipment;
				batchData[openMaterialNoFragment].invoiceDate = "/Date(" + t.getTime() + ")/";
				batchData[openMaterialNoFragment].status = "PENDING";
				formData[openMaterialNoFragment] = batchData[openMaterialNoFragment];
				this._dialog.close();
				this.btnEvent.setIcon("sap-icon://complete");

			}

		},
		/* eslint-enable */
		_validate: function (oControl) {
			/* eslint-disable */
			if (this.getView().byId(oControl).getValue() === "") {
				if (oControl !== "projManNo")
					this.getView().byId(oControl).setValueState("Error");
				return false;
			} else {
				if (oControl !== "projManNo")
					this.getView().byId(oControl).setValueState("None");
				return true;
			}
			/* eslint-enable */
			// if(this.getView().byId("projManNo").getText() == ""){
			// 	this.openMessageBox().error("Project Manager field is empty");
			// 	return false;
			// }

		},
		handleManulaInputCancel: function (event) {
			this._dialog.close();
		},
		/* eslint-disable */
		_submitData: function () {
			//console.log(batchData);
			// Check whether Saved Data lenth is 0 or User does not save all the records Materials
			if (Object.values(batchData).length === 0 || detailsTableRecords.length !== Object.values(batchData).length) {
				this.openMessageBox().error("Please Save all Material Reconciliation form before submit");
				return false;
			}
			var aDeferredGroup = oModel.getDeferredGroups().concat("create");
			oModel.setDeferredGroups(aDeferredGroup);
			oModel.setUseBatch(true);
			var mParameters = {
				groupId: "create"
			};

			for (var key in batchData) {
				if (batchData.hasOwnProperty(key)) {
					oModel.create("/OrderListSet", batchData[key], mParameters);
				}
			}
			var that = this;
			sap.ui.core.BusyIndicator.show();
			oModel.submitChanges({
				success: function (oData, response) {

					var responseArr = response.data.__batchResponses[0].__changeResponses;
					var data2 = {};
					var aMockMessages = [];
					var aMockMessages2 = "";
					for (var j = 0; j < responseArr.length; j++) {
						if (responseArr[j].statusCode === "200" || responseArr[j].statusCode === "201" || responseArr[j].statusCode === "202") {
							data2.type = "Success";
							data2.title = JSON.parse(responseArr[j].headers["sap-message"]).message;
							//aMockMessages2 = aMockMessages2 + JSON.parse(responseArr[j].headers["sap-message"]).message + "\n ";
							aMockMessages2 = "Request submitted Successfully";
						}
						if (responseArr[j].statusCode === "500" || responseArr[j].statusCode === "501" || responseArr[j].statusCode === "503") {
							data2.type = "Error";
							data2.title = JSON.parse(responseArr[j].headers["sap-message"]).message;
							aMockMessages2 = aMockMessages2 + JSON.parse(responseArr[j].headers["sap-message"]).message + "\n ";
						}
						aMockMessages.push(data2);
					}
					//that.openMessagePopover(aMockMessages, that.getView().byId("detailSubmit"));
					if (data2.type === "Success") {
						that.openMessageBox().success(aMockMessages2);
						that.byId("formPreview").setVisible(false);
						that.byId("formPdf").setVisible(true);
					} else {
						that.openMessageBox().error(aMockMessages2);
					}
					that.getView().byId("detailSubmit").setEnabled(false);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (e) {
					//console.log(e);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		/* eslint-enable */
		_previewData: function () {
			//console.log(formData);
			var tableData = this.byId("detailTable").getModel().getData().detailOrderSet;

			if (this.getView().byId("detailSubmit").getEnabled() === false && Object.values(formData).length === 0) {
				//  IF Already Approved Fetch Data from Backend
				var filters = [this._createFilter("orderNo", this.orderNo),
					this._createFilter("jobPeriod", this.jobPeriod),
					this._createFilter("jobYear", this.jobYear)
				];
				for (var k = 0; k < tableData.length; k++) {
					filters.push(this._createFilter("materialNo", tableData[k].materialNo));
				}
			} else {

				if (!this._previewDialog) {
					this._previewDialog = sap.ui.xmlfragment(
						this.getView().getId(),
						"com.tatasteel.ZMM_MATRCON.fragments.Preview",
						this
					).addStyleClass("fragMentHeader");
					this.getView().addDependent(this._previewDialog);
				}
				this._previewDialog.open();
				var previewFragment = this.getView().byId("previewFragment");
				var formInvoiceDate = null;
				var formManager = null;
				for (k = 0; k < tableData.length; k++) {
					if (formData.hasOwnProperty(tableData[k].materialNo)) {
						formData[tableData[k].materialNo].materialDesc = tableData[k].materialDesc;
						formData[tableData[k].materialNo].UOM = tableData[k].UOM;
						formInvoiceDate = sap.ui.core.format.DateFormat.getDateTimeInstance({
							pattern: "dd.MM.yyyy"
						}).format(tableData[k].invoiceDate);
						formManager = this.byId("managerName").getText() + "(" + tableData[k].projManNo + ")";
						if (k === 0) {
							previewFragment.addContent(preview.xmlContent0(formData[tableData[k].materialNo], formInvoiceDate, formManager));
							previewFragment.addContent(new sap.ui.core.HTML({
								content: "<hr></hr>"
							}));
						}
						previewFragment.addContent(preview.xmlContent1(formData[tableData[k].materialNo]));
						previewFragment.addContent(preview.xmlContent2(formData[tableData[k].materialNo]));
						previewFragment.addContent(new sap.ui.core.HTML({
							content: "<hr></hr>"
						}));
					}

				}
			}

		},
		previewClose: function () {
			this.getView().byId("previewFragment").destroyContent();
			this._previewDialog.close();
		},
		_downloadPdf: function (oEvent) {
			try {
				window.open("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/PdfSet(orderNo='" + this.orderNo + "',jobPeriod='" + this.jobPeriod +
					"',jobYear='" + this.jobYear + "',requesterId='" + requesterId + "')/$value");
			} catch (e) {
				/* eslint-disable */
				console.log("An error has occurred: " + e.message);
				/* eslint-enable */
			}
		},
		_serachManager: function (oEvent) {
			var mangerID = oEvent.getSource().getValue().trim();
			var that = this;
			oModel.read("/ManagerSet('" + mangerID + "')", {
				success: function (oData, response) {
					that.getView().byId("managerName").setText(response.data.name);
				},
				error: function (response) {
					that.getView().byId("managerName").setText(JSON.parse(response.responseText).error.message.value);
				}
			});
		},
		_changerelToPlEqp: function (event) {
			if (this.getView().byId("relToPlEqpCombo").getSelectedKey() === "no" || this.getView().byId("otherEquipmentCombo").getSelectedKey() ===
				"no") {
				this.getView().byId("relToPlEqp").setValue("0");
				this.getView().byId("otherEquipment").setValue("100");
			} else if (this.getView().byId("relToPlEqpCombo").getSelectedKey() === "yes" && this.getView().byId("otherEquipmentCombo").getSelectedKey() ===
				"yes") {
				this.getView().byId("relToPlEqp").setValue("50");
				this.getView().byId("otherEquipment").setValue("50");
			} else {
				this.getView().byId("relToPlEqp").setValue("");
				this.getView().byId("otherEquipment").setValue("");
			}
		},
		_changeotherEquipment: function (event) {
			if (this.getView().byId("relToPlEqpCombo").getSelectedKey() === "no" || this.getView().byId("otherEquipmentCombo").getSelectedKey() ===
				"no") {
				this.getView().byId("relToPlEqp").setValue("0");
				this.getView().byId("otherEquipment").setValue("100");
			} else if (this.getView().byId("relToPlEqpCombo").getSelectedKey() === "yes" && this.getView().byId("otherEquipmentCombo").getSelectedKey() ===
				"yes") {
				this.getView().byId("relToPlEqp").setValue("50");
				this.getView().byId("otherEquipment").setValue("50");
			} else {
				this.getView().byId("relToPlEqp").setValue("");
				this.getView().byId("otherEquipment").setValue("");
			}
		},
		_createFilter: function (path, value) {
			return new sap.ui.model.Filter({
				path: path,
				operator: sap.ui.model.FilterOperator.EQ,
				value1: value
			});
		},
		clearAllControl: function () {
			var ids = (
				"invoiceNo invoiceDate vendorRepresentative projManNo"
			).split(" ");
			var that = this;
			jQuery.each(ids, function (i, oInput) {
				that.getView().byId(oInput).setValue(null);
				if (oInput !== "projManNo") {
					that.getView().byId(oInput).setValueState("None");
				}
			});
			that.getView().byId("managerName").setText("");
		},
		goBack: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("", false);

			// var oHistory = History.getInstance();
			// var sPreviousHash = oHistory.getPreviousHash();
			// if (sPreviousHash !== undefined) {
			// 	window.history.go(-1);
			// } else {
			// 	oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// 	oRouter.navTo("", true);
			// }
		}

	});

});