sap.ui.define([
	// "sap/ui/core/mvc/Controller",
	"com/tatasteel/ZMM_MATRCON/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/tatasteel/ZMM_MATRCON/model/formatter"
], function (BaseController, JSONModel, Filter, FilterOperator, formatter) {
	"use strict";
	var oRouter;
	return BaseController.extend("com.tatasteel.ZMM_MATRCON.controller.Home", {
		formatter: formatter,
		onInit: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		},
		onBeforeRendering: function () {
			//this.getOrders(this.getFilters());
		},
		onSearch: function () {
			this.getOrders(this.getFilters());
		},
		getFilters: function () {
			var filters = [];
			if (this.getView().byId("orderNo").getValue() !== "") {
				filters.push(new sap.ui.model.Filter({
					path: "orderNo",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this.getView().byId("orderNo").getValue()
				}));
			}
			if (this.getView().byId("vendorCode").getValue() !== "") {
				filters.push(new sap.ui.model.Filter({
					path: "vendorCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: this.getView().byId("vendorCode").getValue().toUpperCase()
				}));
			}
			return filters;
		},
		getOrders: function (filters) {
			//var that = this;
			this.getView().byId("table").setBusy(true);
			var freeOrderTable = this.getView().byId("table");
			var oBinding = freeOrderTable.getBinding("items");
			oBinding.filter(filters);
			this.getView().byId("table").setBusy(false);
			
			// this.getView().byId("table").setBusy(true);
			// oModel.read("/FreeOrderSet", {
			// 	filters: filters,
			// 	success: function (oData, response) {
			// 		var freeOrderTable = that.getView().byId("table");
			// 		var jsonModel = new JSONModel();
			// 		jsonModel.setData({
			// 			freeOrderSet: oData.results
			// 		});
			// 		freeOrderTable.setModel(jsonModel);
			// 		freeOrderTable.setBusy(false);
			// 	},
			// 	error: function (oData, response) {
			// 		that.getView().byId("table").setBusy(false);
			// 		//console.log(response);
			// 		that.openMessageBox("", "error");        
			// 	}
			// });

			// var freeOrderTable = this.getView().byId("table");
			// freeOrderTable.getModel().read("/FreeOrderSet?$top=10&skip=0", {
			// 	filters: filters,
			// 	success: function (oData) {
			// 		console.log(oData);
			// 		var jsonModel = new JSONModel();
			// 		jsonModel.setData({
			// 			freeOrderSet: oData.results
			// 		});
			// 		freeOrderTable.setModel(jsonModel);
			// 	},
			// 	error: function (oError) {}
			// });

		},
		filterGlobally: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			this._oGlobalFilter = null;

			if (sQuery) {
				this._oGlobalFilter = new Filter([
					new Filter("orderNo", FilterOperator.Contains, sQuery),
					new Filter("ManagerName", FilterOperator.Contains, sQuery),
					new Filter("Status", FilterOperator.Contains, sQuery)
				], false);
			}

			this._filter();
		},
		_filter: function () {
			var oFilter = null;
			if (this._oGlobalFilter) {
				oFilter = this._oGlobalFilter;
			}
			//this.getView().byId("table").getBinding("items").filter(oFilter, "Application");
			this.getView().byId("table").getBinding("items").filter(oFilter);
		},
		goToDetailSection: function (oEvent) {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("DetailSection", {
				orderNo: oEvent.getSource().getBindingContext().getProperty("orderNo"),
				jobPeriodYear: oEvent.getSource().getBindingContext().getProperty("JobPeriod").trim() + "-" + oEvent.getSource().getBindingContext().getProperty(
					"JobYear").trim(),
				vCode: oEvent.getSource().getBindingContext().getProperty("vendorCode")
			});
		}

	});
});