sap.ui.define([
		"com/tatasteel/ZMM_MATRCON/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("com.tatasteel.ZMM_MATRCON.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("RouteHome");
			}

		});

	}
);