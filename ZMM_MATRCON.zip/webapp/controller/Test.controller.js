sap.ui.define([
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/tatasteel/ZMM_MATRCON/model/formatter"
], function (Fragment, Controller, History, JSONModel, formatter, MessageBox) {
	"use strict";
	var oRouter;
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/");

	return Controller.extend("com.tatasteel.ZMM_MATRCON.controller.Test", {
		formatter: formatter,
		onInit: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("DetailSection").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function (oEvent) {
			sap.ui.getCore().setModel({}, "fragmentModel");
			var jobPeriodYear = oEvent.getParameter("arguments").jobPeriodYear; // Get Job and Year from URL
			var firstDate = new Date(jobPeriodYear.split("-")[1], jobPeriodYear.split("-")[0] - 1, 1);
			var lastDay = new Date(jobPeriodYear.split("-")[1], jobPeriodYear.split("-")[0], 0);
			this.getView().byId("firstDate").setText(firstDate.getDate() + "." + (firstDate.getMonth() + 1) + "." + firstDate.getFullYear());
			this.getView().byId("lastDate").setText(lastDay.getDate() + "." + (lastDay.getMonth() + 1) + "." + lastDay.getFullYear());
			this.orderNo = oEvent.getParameter("arguments").orderNo;
			this.jobPeriod = Number(jobPeriodYear.split("-")[0]);
			this.jobYear = jobPeriodYear.split("-")[1];
			var filters = [];
			filters.push(new sap.ui.model.Filter({
				path: "orderNo",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").orderNo
			}));
			filters.push(new sap.ui.model.Filter({
				path: "jobPeriod",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: jobPeriodYear.split("-")[0]
			}));
			filters.push(new sap.ui.model.Filter({
				path: "jobYear",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: jobPeriodYear.split("-")[1]
			}));

			var that = this;
			oModel.read("/DetailSectionSet", {
				filters: filters,
				success: function (oData, response) {
					allResponseData = [];
					var detailTable = that.getView().byId("detailTable");
					var jsonModel = new JSONModel();
					var uniqueRecords = that._uniqueRecords(oData.results);
					jsonModel.setData({
						detailOrderSet: uniqueRecords
					});
					detailTable.setModel(null);
					detailTable.setModel(jsonModel);
					// detailTable.bindItems({
					// 	path: "/detailOrderSet",
					// 	template: detailTable.getBindingInfo("items").template
					// });
					//that.setFragment(oData.results);
					allResponseData = oData.results;

					// 					const inventory = [
					//   {name: 'apples', quantity: 2},
					//   {name: 'bananas', quantity: 0},
					//   {name: 'cherries', quantity: 5}
					// ];

					// const result = inventory.find( ({ name }) => name === 'cherries' );

					// console.log(result) // { name: 'cherries', quantity: 5 }

				}
			});
		},
		_uniqueRecords: function (results) {
			var uniqueArray = [];
			for (var i = 0; i < results.length; i++) {
				if (uniqueArray.indexOf(results[i]) === -1) {
					uniqueArray.push(results[i]);
				}
				return uniqueArray;
			}
		},
		setFragment: function (results) {
			var freeIssueIMSection = 0;
			var nonFreeIssueIMSection = 0;
			for (var i = 0; i < results.length; i++) {
				if (results[i].woIssueType.toUpperCase() === "FREE ISSUE MATERIAL TO VENDOR") {
					freeIssueIMSection = parseFloat(freeIssueIMSection) + parseFloat(results[i].quantity);
				} else if (results[i].woIssueType.toUpperCase() === "NON-FREE ISSUE MATERIAL") {
					nonFreeIssueIMSection = parseFloat(nonFreeIssueIMSection) + parseFloat(results[i].quantity);
				}
			}

			//var jsonModel = new JSONModel();
			this.data = {
				freeIssueIMSection: freeIssueIMSection, // (A)
				nonFreeIssueIMSection: nonFreeIssueIMSection, // (B)
				netIssueQuantity: Number((parseFloat(freeIssueIMSection) + parseFloat(nonFreeIssueIMSection)).toFixed(2)), // (C=A+B)
				conQtyPrevRec: 0, // (D)
				conQtyBill: 0, // (E)
				unAccWtgPreRec: 0, // (G)
				unAccWtgBill: 0, // (H)
				accWtgQtyPreRec: 0, // (J)
				accWtgQtyBill: 0 // (K)
			};
			this.setfragmentData(this.data);
		},
		setfragmentData: function (data) {
			var jsonModel = new JSONModel();
			data.conQtyTot = parseFloat(data.conQtyPrevRec) + parseFloat(data.conQtyBill); // (F=D+E)
			data.unAccWtgTot = parseFloat(data.unAccWtgPreRec) + parseFloat(data.unAccWtgBill); // (I=G+H)
			data.accWtgQtyTot = parseFloat(data.accWtgQtyPreRec) + parseFloat(data.accWtgQtyBill); // (L=J+K)
			data.balanceQty = parseFloat(data.conQtyTot) + parseFloat(data.unAccWtgTot) + parseFloat(data.accWtgQtyTot) +
				parseFloat(data.netIssueQuantity); // (M=C-F-I-L)
			jsonModel.setData(data);
			sap.ui.getCore().setModel({}, "fragmentModel");
			sap.ui.getCore().setModel(jsonModel, "fragmentModel");
			if (typeof this._dialog !== "undefined") {
				this._dialog.setModel(sap.ui.getCore().getModel("fragmentModel"));
			}
		},
		openFormFragment: function (event) {
			sap.ui.core.BusyIndicator.show(5);
			this.materialNo = event.getSource().getParent().getCells()[1].getText(); // Catch the Material Number
			// jQuery.each(allResponseData, function (i, oInput) {
			// });	

			if (!this._dialog) {
				//var path = oEvent.getSource().getBindingContext().getPath();
				this._dialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.tatasteel.ZMM_MATRCON.fragments.ManualInput",
					this
				);
				this.getView().addDependent(this._dialog);
				//this._dialog.open();
			}
			this.setFragment(allResponseData);
			sap.ui.core.BusyIndicator.hide();
			this._dialog.setModel(sap.ui.getCore().getModel("fragmentModel"));
			this._dialog.open();

		},
		upDateModel: function (oEvent) {
			var t = sap.ui.getCore().getModel("fragmentModel");
			t.setProperty("/" + oEvent.getSource().getId().split("--")[1], Number(parseFloat(oEvent.getParameters().value)));
			sap.ui.getCore().getModel("fragmentModel").refresh(true);
			this.setfragmentData(sap.ui.getCore().getModel("fragmentModel").getData());
		},
		handleManulaInputSubmit: function (oEvent) {
			var data = {};
			var that = this;
			var errors = 0;
			var ids = (
				"invoiceNo invoiceDate vendorName projManNo relToPlEqp otherEquipment freeIssueIMSection nonFreeIssueIMSection netIssueQuantity conQtyPrevRec conQtyBill conQtyTot unAccWtgPreRec unAccWtgBill unAccWtgTot accWtgQtyPreRec accWtgQtyBill balanceQty"
			).split(" ");
			data.orderNo = this.orderNo;
			data.jobPeriod = this.jobPeriod.toString();
			data.jobYear = this.jobYear;
			data.materialNo = this.materialNo;
			jQuery.each(ids, function (i, oInput) {
				if (that._validate(oInput)) {
					data[oInput] = that.getView().byId(oInput).getValue().trim();
				} else {
					errors = errors + 1;
				}
			});
			if (errors > 0)
				sap.m.MessageBox.error("Please input all the fields");
			else {
				data.invoiceDate = "/Date(" + that.getView().byId("invoiceDate").getDateValue().getTime() + ")/";
				that._submitData(JSON.stringify(data));
			}
			//console.log( JSON.stringify(data) );
		},
		_validate: function (oControl) {
			if (this.getView().byId(oControl).getValue() === "") {
				if (oControl !== "projManNo")
					this.getView().byId(oControl).setValueState("Error");
				return false;
			} else {
				//this.getView().byId(oControl).setValueState("Default");
				return true;
			}
		},
		handleManulaInputCancel: function (event) {
			this._dialog.close();
		},
		_submitData: function (data) {
			oModel.create("/OrderListSet", JSON.parse(data), {
				success: function (oData, response) {

				},
				error: function (oData, response) {

				}

			});
		},
		goBack: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("RouteHome", true);
		},
	});

});