sap.ui.define([], function () {
	"use strict";
	return {
		jobMonth: function (JobPeriod, JobYear) {
			switch (JobPeriod.trim()) {
			case "01":
				return "January '" + JobYear;
			case "1":
				return "January '" + JobYear;
			case "02":
				return "February '" + JobYear;
			case "2":
				return "February '" + JobYear;
			case "03":
				return "March '" + JobYear;
			case "3":
				return "March '" + JobYear;
			case "04":
				return "April '" + JobYear;
			case "4":
				return "April '" + JobYear;
			case "05":
				return "May '" + JobYear;
			case "5":
				return "May '" + JobYear;
			case "06":
				return "June '" + JobYear;
			case "6":
				return "June '" + JobYear;
			case "07":
				return "July '" + JobYear;
			case "7":
				return "July '" + JobYear;
			case "08":
				return "August '" + JobYear;
			case "8":
				return "August '" + JobYear;
			case "09":
				return "September '" + JobYear;
			case "9":
				return "September '" + JobYear;
			case "10":
				return "October '" + JobYear;
			case "11":
				return "November '" + JobYear;
			case "12":
				return "December '" + JobYear;
			default:
				return JobPeriod + " '" + JobYear;
			}
		},
		setStatus: function (status) {
			switch (status) {
			case "PENDING":
				return status + " with PM";
			case "REJECTED":
				return status + " by PM";
			case "":
				return "NOT INITIATED";
			default:
				return status;
			}

		},
		setState: function (status) {
			switch (status) {
			case "APPROVED":
				return "Success";
			case "PENDING":
				return "Warning";
			case "REJECTED":
				return "Error";
			default:
				return "None";
			}

		},
		setStateIcon: function (status) {
			switch (status) {
			case "APPROVED":
				return "sap-icon://accept";
			case "PENDING":
				return "sap-icon://pending";
			case "REJECTED":
				return "sap-icon://decline";
			default:
				return "sap-icon://warning";
			}
		},
		deviceType: function () {
			return sap.ui.Device.system.desktop;
		},
		wrapText: function (remarks) {
			if (sap.ui.Device.system.desktop && remarks.length > 0) {
				if (remarks.length > 20) {
					return remarks.substring(0, 20) + "...";
				} else {
					return remarks;
				}
			}
			if (sap.ui.Device.system.phone && remarks.length > 0) {
				if (remarks.length > 50) {
					return remarks.substring(0, 50) + "...";
				} else {
					return remarks;
				}
			}
		},
		visibleMore: function (remarks) {
			if (sap.ui.Device.system.desktop && remarks.length > 0) {
				if (remarks.length > 20) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
			if (sap.ui.Device.system.phone && remarks.length > 0) {
				if (remarks.length > 50) {
					return true;
				} else {
					return false;
				}
			}
		}

	};
});