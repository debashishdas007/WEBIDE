sap.ui.define([], function () {
	"use strict";
	return {
		jobMonth: function (JobPeriod, JobYear) {
			// switch (JobPeriod.trim()) {
			switch (JobPeriod) {
			case "01":
				return "January '" + JobYear;
			case 1:
				return "January '" + JobYear;
			case "02":
				return "February '" + JobYear;
			case 2:
				return "February '" + JobYear;
			case "03":
				return "March '" + JobYear;
			case 3:
				return "March '" + JobYear;
			case "04":
				return "April '" + JobYear;
			case 4:
				return "April '" + JobYear;
			case "05":
				return "May '" + JobYear;
			case 5:
				return "May '" + JobYear;
			case "06":
				return "June '" + JobYear;
			case 6:
				return "June '" + JobYear;
			case "07":
				return "July '" + JobYear;
			case 7:
				return "July '" + JobYear;
			case "08":
				return "August '" + JobYear;
			case 8:
				return "August '" + JobYear;
			case "09":
				return "September '" + JobYear;
			case 9:
				return "September '" + JobYear;
			case "10":
				return "October '" + JobYear;
			case 10:
				return "October '" + JobYear;	
			case "11":
				return "November '" + JobYear;
			case 11:
				return "November '" + JobYear;	
			case "12":
				return "December '" + JobYear;	
			case 12:
				return "December '" + JobYear;
			default:
				return JobPeriod + " '" + JobYear;
			}
		},
		setStatus: function (status) {
			switch (status) {
			case "PENDING":
				return status + " with PM";
			case "REJECTED":
				return status + " by PM";
			case "":
				return "NOT INITIATED";
			default:
				return status;
			}

		},
		setState: function (status) {
			switch (status) {
			case "APPROVED":
				return "Success";
			case "PENDING":
				return "Warning";
			case "REJECTED":
				return "Error";
			default:
				return "None";
			}

		},
		setStateIcon: function (status) {
			switch (status) {
			case "APPROVED":
				return "sap-icon://accept";
			case "PENDING":
				return "sap-icon://pending";
			case "REJECTED":
				return "sap-icon://decline";
			default:
				return "sap-icon://warning";
			}
		},
		monthSet: function () {
			return {
				"monthCollection": [{
					"key": 1,
					"text": "01-January"
				}, {
					"key": 2,
					"text": "02-February"
				}, {
					"key": 3,
					"text": "03-March"
				}, {
					"key": 4,
					"text": "04-April"
				}, {
					"key": 5,
					"text": "05-May"
				}, {
					"key": 6,
					"text": "06-June"
				}, {
					"key": 7,
					"text": "07-July"
				}, {
					"key": 8,
					"text": "08-August"
				}, {
					"key": 9,
					"text": "09-September"
				}, {
					"key": 10,
					"text": "10-October"
				}, {
					"key": 11,
					"text": "11-November"
				}, {
					"key": 12,
					"text": "12-December"
				}]
			};

		},
		deviceType: function () {
			return sap.ui.Device.system.desktop;
		},
		removingZeros: function (materialNo) {
			if (materialNo !== null) {
				return (materialNo.replace(/^0+/, "")).trim();
			} else {
				return materialNo;
			}
		},
		wrapText: function (remarks) {
			if (sap.ui.Device.system.desktop && remarks.length > 0) {
				if (remarks.length > 20) {
					return remarks.substring(0, 20) + "...";
				} else {
					return remarks;
				}
			}
			if (sap.ui.Device.system.phone && remarks.length > 0) {
				if (remarks.length > 30) {
					return remarks.substring(0, 30) + "...";
				} else {
					return remarks;
				}
			}
		},
		visibleMore: function (remarks) {
			if (sap.ui.Device.system.desktop && remarks.length > 0) {
				if (remarks.length > 20) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
			if (sap.ui.Device.system.phone && remarks.length > 0) {
				if (remarks.length > 50) {
					return true;
				} else {
					return false;
				}
			}
		},
		excelFields: function () {
			return [{
					name: "Order Number",
					template: {
						content: "{orderNo}"
					}
				},
				{
					name: "Vendor Code",
					template: {
						content: "{vendorCode}"
					}
				}, 
				{
					name: "Period",
					template: {
						content : {
							parts : [{path: "JobPeriod"}, {path: "JobYear"}],
							formatter : function(JobPeriod, JobYear) {
								return this.jobMonth(JobPeriod, JobYear);
							}.bind(this)
						}
					}
				},{
					name: "Requester",
					template: {
						content: "{requesterId}"
					}
				},
				{
					name: "Invoice No",
					template: {
						content: "{invoiceNo}"
					}
				},
				{
					name: "Invoice date",
					template: {
						content: {path: "invoiceDate", type:"sap.ui.model.type.Date", formatOptions: { pattern: "dd.MM.YYYY" } }
					}
				},
				{
					name: "Project Manager Name",
					template: {
						content: "{ManagerName}"
					}
				},
				{
					name: "Status",
					template: {
						content: "{Status}"
					}
				}, {
					name: "Remarks",
					template: {
						content: "{Remarks}"
					}
				}
			];
		},
		formatDateStr: function (sValue) {
			if (sValue) {
				var dateString = sValue;
				var year = dateString.substring(0, 4);
				var month = dateString.substring(4, 6);
				var day = dateString.substring(6, 8);
				var hh = dateString.substring(9, 11);
				var mm = dateString.substring(11, 13);
				var ss = dateString.substring(13, 15);
				return (new Date(year, month - 1, day).toShortFormat()) + " " + hh + ":" + mm + ":" + ss;
			} else {
				return sValue;
			}

		},
		workOrderLastDate: function(lastDate, validityEnd){
			var days = Math.floor((Date.UTC(validityEnd.getFullYear(), validityEnd.getMonth(), validityEnd.getDate()) - Date.UTC(lastDate.getFullYear(), lastDate.getMonth(), lastDate.getDate()) ) /(1000 * 60 * 60 * 24));
			if( days > 0 ){
				return lastDate;
			}else{
				return validityEnd;
			}
		}

	};
});