sap.ui.define([
	"com/tatasteel/ZMM_MATRCON/test/unit/controller/Home.controller"
], function () {
	"use strict";
});