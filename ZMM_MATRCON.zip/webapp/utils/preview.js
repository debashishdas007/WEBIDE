sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/UIComponent"
], function () {
	"use strict";
	return {
		xmlContent0: function (formData, formInvoiceDate, formManager) {
			var _lgrid0 = new sap.ui.layout.Grid({
				containerQuery: true,
				defaultSpan: "XL2 L2 M4 S12",
				position: "Center",
				content: [
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Work Order"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.orderNo
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Invoice Number"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.invoiceNo
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					// {path: 'formData.invoiceDate', type:'sap.ui.model.type.Date', formatOptions: { pattern: 'dd.MM.YYYY' } }
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Invoice Date"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formInvoiceDate
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
										text: "Vendor Representative Name"
									}).addStyleClass("prvtxt"),
									new sap.m.Label({
										text: formData.vendorRepresentative
									}).addStyleClass("prvtxtOpt")
								]
								// {path: 'headerSection>/invoiceDate', type:'sap.ui.model.type.Date', formatOptions: { pattern: 'dd.MM.YYYY' } }
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Project Manager"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formManager      // formData.projManNo
								}).addStyleClass("prvtxtOpt")
							]
						})]
					})

				]
			}).addStyleClass("sapUiSmallMargin sapUiSmallMarginTop");
			return _lgrid0;
		},
		xmlContent1: function (formData) {
			var _lgrid1 = new sap.ui.layout.Grid({
				containerQuery: true,
				defaultSpan: "XL2 L2 M4 S12",
				position: "Center",
				content: [
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Materail Number"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.materialNo
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Material Description"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.materialDesc
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "UOM"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.UOM
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Segment"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.segment
								}).addStyleClass("prvtxtOpt")
							]
						})]
					}),
					new sap.m.HBox({
						fitContainer: true,
						items: [new sap.m.VBox({
							fitContainer: true,
							justifyContent: "Center",
							items: [new sap.m.Label({
									text: "Balance Qty"
								}).addStyleClass("prvtxt"),
								new sap.m.Label({
									text: formData.balanceQty
								}).addStyleClass("prvtxtOpt")
							]
						})]
					})
				]
			}).addStyleClass("sapUiSmallMargin sapUiSmallMarginTop");
			return _lgrid1;
		},
		xmlContent2: function (formData) {
			var _lgrid2 = new sap.ui.layout.Grid({
				containerQuery: true,
				defaultSpan: "XL3 L3 M4 S12",
				position: "Center",
				content: [
					new sap.m.VBox({
						fitContainer: true,
						wrap: "Wrap",
						items: [
							//new sap.m.Label({wrapping: true, text: "{i18n>freeIssueIMSection}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.freeIssueIMSection }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							//new sap.m.Label({wrapping: true, text: "{i18n>nonFreeIssueIMSection}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.nonFreeIssueIMSection }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							new sap.m.Label({
								wrapping: true,
								text: "{i18n>netIssueQuantity}"
							}).addStyleClass("prvtxt"),
							new sap.m.Label({
								wrapping: true,
								text: formData.netIssueQuantity
							}).addStyleClass("prvtxtOpt")
						]
					}),
					new sap.m.VBox({
						fitContainer: true,
						wrap: "Wrap",
						items: [
							//new sap.m.Label({wrapping: true, text: "{i18n>conQtyPrevRec}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.conQtyPrevRec }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							//new sap.m.Label({wrapping: true, text: "{i18n>conQtyBill}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.conQtyBill }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							new sap.m.Label({
								wrapping: true,
								text: "{i18n>conQtyTot}"
							}).addStyleClass("prvtxt"),
							new sap.m.Label({
								wrapping: true,
								text: formData.conQtyTot
							}).addStyleClass("prvtxtOpt")
						]
					}),
					new sap.m.VBox({
						fitContainer: true,
						wrap: "Wrap",
						items: [
							//   new sap.m.Label({wrapping: true, text: "{i18n>unAccWtgPreRec}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.unAccWtgPreRec }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							//new sap.m.Label({wrapping: true, text: "{i18n>unAccWtgBill}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.unAccWtgBill }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							new sap.m.Label({
								wrapping: true,
								text: "{i18n>unAccWtgTot}"
							}).addStyleClass("prvtxt"),
							new sap.m.Label({
								wrapping: true,
								text: formData.unAccWtgTot
							}).addStyleClass("prvtxtOpt")
						]
					}),
					new sap.m.VBox({
						fitContainer: true,
						wrap: "Wrap",
						items: [
							//   new sap.m.Label({wrapping: true, text: "{i18n>accWtgQtyPreRec}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.accWtgQtyPreRec }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							//new sap.m.Label({wrapping: true, text: "{i18n>accWtgQtyBill}"}).addStyleClass("prvtxt"),
							//new sap.m.Label({wrapping: true, text: formData.accWtgQtyBill }).addStyleClass("prvtxtOpt sapUiTinyMarginBottom"),
							new sap.m.Label({
								wrapping: true,
								text: "{i18n>accWtgQtyTot}"
							}).addStyleClass("prvtxt"),
							new sap.m.Label({
								wrapping: true,
								text: formData.accWtgQtyTot
							}).addStyleClass("prvtxtOpt")
						]
					})
				]
			}).addStyleClass("sapUiSmallMargin sapUiSmallMarginTop");

			return _lgrid2;
		}
	};
});