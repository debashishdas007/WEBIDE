sap.ui.define([
	"sap/ui/core/Fragment",
	"com/tatasteel/ZMM_MATRCON_APR/controller/BaseController",
	"sap/m/Dialog",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"com/tatasteel/ZMM_MATRCON_APR/model/formatter"
], function (Fragment, BaseController, Dialog, History, JSONModel, MessageBox, formatter) {
	"use strict";
	var oRouter;
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/");
	//var openMaterialNoFragment = "";
	return BaseController.extend("com.tatasteel.ZMM_MATRCON_APR.controller.DetailSection", {
		formatter: formatter,
		onInit: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("DetailSection").attachPatternMatched(this._onObjectMatched, this);

		},
		_onObjectMatched: function (oEvent) {
			sap.ui.getCore().setModel({}, "fragmentModel");
			var jobPeriodYear = oEvent.getParameter("arguments").jobPeriodYear; // Get Job and Year from URL
			this.jobPeriod = Number(jobPeriodYear.split("-")[0]);
			this.jobYear = jobPeriodYear.split("-")[1];
			this.orderNo = oEvent.getParameter("arguments").orderNo;
			this.requesterId = oEvent.getParameter("arguments").requesterId;
			var filters = [];
			filters.push(new sap.ui.model.Filter({
				path: "orderNo",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").orderNo
			}));
			filters.push(new sap.ui.model.Filter({
				path: "jobPeriod",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: jobPeriodYear.split("-")[0]
			}));
			filters.push(new sap.ui.model.Filter({
				path: "jobYear",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: jobPeriodYear.split("-")[1]
			}));
			filters.push(new sap.ui.model.Filter({
				path: "requesterId",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: oEvent.getParameter("arguments").requesterId
			}));

			var that = this;
			this.getView().byId("detailTable").setBusy(true);
			oModel.read("/DetailTableSet", {
				filters: filters,
				success: function (oData, response) {
					// allResponseData = [];
					var detailTable = that.getView().byId("detailTable");
					var jsonModel = new JSONModel();
					detailTable.setModel(null);
					if (oData.results.length > 0) {
						that.getView().setModel(new JSONModel(oData.results[0]), "headerRow");
						if (oData.results[0].status !== "PENDING" || oData.results[0].status === "APPROVED" || oData.results[0].status === "REJECTED") {
							jsonModel.setData({
								detailOrderSet: oData.results,
								buttonSet: false
							});
						} else {
							jsonModel.setData({
								detailOrderSet: oData.results,
								buttonSet: true
							});
						}
						detailTable.setModel(jsonModel);
					}
					that.getView().byId("detailTable").setBusy(false);
				}
			});
		},

		openFragment: function (oEvent) {
			// oEvent.getSource().getBindingContext().getObject()
			//sap.ui.core.BusyIndicator.show();
			if (!this._dialog) {
				this._dialog = sap.ui.xmlfragment(
					this.getView().getId(),
					"com.tatasteel.ZMM_MATRCON_APR.fragments.Preview",
					this
				).addStyleClass("fragMentHeader");
				this.getView().addDependent(this._dialog);
			}
			
			this._dialog.open();
			this.byId("previewFragment").setModel(new JSONModel(oEvent.getSource().getBindingContext().getObject()), "fragmentData");    
			//this.fragmentData(oEvent);
		},
		closeFragemnt: function () {
			this._dialog.close();
		},

		// fragmentData: function (oEvent) {
		// 	var orderNo = oEvent.getSource().getBindingContext().getProperty("orderNo");
		// 	var jobPeriod = this.jobPeriod;
		// 	var jobYear = this.jobYear;
		// 	this.materialNo = oEvent.getSource().getBindingContext().getProperty("materialNo");
		// 	var that = this;
		// 	oModel.read("/CumulativeQtySet(orderNo='" + orderNo + "',jobPeriod='" + jobPeriod + "',jobYear='" + jobYear +
		// 		"',materialNo='" + this.materialNo + "')", {
		// 			success: function (oData, response) {
		// 				var jsonModel = new JSONModel();
		// 				jsonModel.setData(oData);
		// 				that.getView().setModel(jsonModel);
		// 				sap.ui.core.BusyIndicator.hide();
		// 				that._dialog.open();
		// 			},
		// 			error: function (oData, response) {
		// 				sap.ui.core.BusyIndicator.hide();
		// 				//console.log("Error Because of Data not Found in YMPIT_MAT_RCON Table");
		// 			}
		// 		});

		// },

		_submitData: function (oEvent) {
			this.type = oEvent.getSource().getType();
			this.clickBtn = oEvent.getSource();
			var type = oEvent.getSource().getType();
			var that = this;
			var oDialog = new Dialog({
				title: "Confirm",
				type: "Message",
				content: [
					new sap.m.Label({
						text: "Please Add a Remarks",
						labelFor: "submitDialogTextarea"
					}),
					new sap.m.TextArea("submitDialogTextarea", {
						liveChange: function (event) {
							var sText = event.getParameter("value");
							var parent = event.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: "100%",
						placeholder: "Add note (required)"
					})
				],
				beginButton: new sap.m.Button({
					type: type,
					text: "Submit",
					enabled: false,
					press: function () {
						var remarksText = sap.ui.getCore().byId("submitDialogTextarea").getValue();
						that._submitFinalRemarks(remarksText, that);
						oDialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});
			oDialog.open();
		},
		/* eslint-disable */
		_submitFinalRemarks: function (remarks, that) {
			//console.log(remarks);
			var status = "";
			var data = {};
			if (that.type === "Accept")
				status = "APPROVED";
			else if (that.type === "Reject")
				status = "REJECTED";

			var tableData = this.getView().byId("detailTable").getModel().getData().detailOrderSet;
			var aDeferredGroup = oModel.getDeferredGroups().concat("update");
			oModel.setDeferredGroups(aDeferredGroup);
			oModel.setUseBatch(true);
			var mParameters = {
				groupId: "update"
			};

			for (var i = 0; i < tableData.length; i++) {
				data = {
					// orderNo: tableData[i].orderNo,
					// jobPeriod: that.jobPeriod,
					// jobYear: that.jobYear,
					// materialNo: tableData[i].materialNo,
					status: status,
					remarks: remarks
				};
				//oModel.sDefaultUpdateMethod = "PUT";
				sap.ui.core.BusyIndicator.show();
				oModel.update("/CumulativeQtySet(orderNo='" + tableData[i].orderNo + "',jobPeriod='" + that.jobPeriod + "',jobYear='" + that.jobYear +
					"',materialNo='" + tableData[i].materialNo + "',requesterId='"+ this.requesterId +"')", data, mParameters);

			}
			oModel.submitChanges({
				success: function (oData, response) {
					//console.log(response);
					var responseArr = "";
					var data2 = {};
					var aMockMessages = [];
					var aMockMessages2 = "";
					if (typeof (oData.__batchResponses[0].__changeResponses) === "undefined") {
						/*  Error Response is 500||503  */
						responseArr = oData.__batchResponses[0];
						data2.type = "Error";
						data2.title = JSON.parse(responseArr.response.body).error.message.value;
						aMockMessages2 = aMockMessages2 + JSON.parse(responseArr.response.body).error.message.value + "\n ";
						aMockMessages.push(data2);
					} else {
						responseArr = oData.__batchResponses[0].__changeResponses;
						for (var j = 0; j < responseArr.length; j++) {
							if (responseArr[j].statusCode === "200" || responseArr[j].statusCode === "201" || responseArr[j].statusCode === "202" ||
								responseArr[j].statusCode === "203" || responseArr[j].statusCode === "204") {
								data2.type = "Success";
								data2.title = JSON.parse(responseArr[j].headers["sap-message"]).message;
								//aMockMessages2 = aMockMessages2 + JSON.parse(responseArr[j].headers["sap-message"]).message + "\n ";
								aMockMessages2 = "Request " + status + " Successfully";
							}
							aMockMessages.push(data2);
						}
					}
					//that.openMessagePopover(aMockMessages, that.clickBtn);
					if (data2.type === "Success") {
						that.openMessageBox().success(aMockMessages2);
					} else {
						that.openMessageBox().error(aMockMessages2);
					}
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (e) {
					//console.log(e);
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		/* eslint-enable */
		/* eslint-disable */
		_downloadPdf: function (oEvent) {
			try {
				window.open("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/PdfSet(orderNo='" + this.orderNo + "',jobPeriod='" + this.jobPeriod +
					"',jobYear='" + this.jobYear + "')/$value");
			} catch (e) {
				/* eslint-disable */
				console.log("An error has occurred: " + e.message);
				/* eslint-enable */
			}

			//var sURI = "/sap/opu/odata/sap/YMM_MAT_RCON_SRV/";
			//var oModel = new sap.ui.model.odata.ODataModel(sURI, true);
			// oModel.read(
			// 	"/PdfSet(orderNo='" +this.orderNo+ "',jobPeriod='" +this.jobPeriod+ "',jobYear='" +this.jobYear+ "')/$value",
			// 	null, null, false,
			// 	function (odata, response) {
			// 		if (response === null) {
			// 		} else {
			// 			var pdfURL = response.requestUri;
			// 			var link = document.createElement("a");
			// 			link.href = atob(response.body);
			// 			link.download = "link";
			// 			link.click();
			// 			//window.open(pdfURL);
			// 		}

			// 	},
			// 	function fnError(e) {
			// 		var errorBody = e.response.body;
			// 		var errorMessage = JSON.parse(errorBody).error.message.value;

			// 		// On Error
			// 		// context._showStatusDialog(context, "Error", "Message",
			// 		// 	"Error", "Error while processing the order details: " + errorMessage);
			// 	});

		},
		/* eslint-enable */
		goBack: function () {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("", true);
			// var oHistory = History.getInstance();
			// var sPreviousHash = oHistory.getPreviousHash();

			// if (sPreviousHash !== undefined) {
			// 	window.history.go(-1);
			// } else {
			// 	oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// 	oRouter.navTo("RouteHome", true);
			// }
		}
	});

});