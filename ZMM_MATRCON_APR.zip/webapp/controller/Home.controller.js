sap.ui.define([
	"com/tatasteel/ZMM_MATRCON_APR/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"com/tatasteel/ZMM_MATRCON_APR/model/formatter"
], function (BaseController, JSONModel, Dialog, Filter, FilterOperator, formatter) {
	"use strict";
	var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/YMM_MAT_RCON_SRV/");
	var oRouter;
	return BaseController.extend("com.tatasteel.ZMM_MATRCON_APR.controller.Home", {
		formatter: formatter,
		onInit: function () {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this.byId("month").setModel(new JSONModel(formatter.monthSet()));
		},
		onAfterRendering: function () {
			console.log("onAfter");
			this.getOrders(this.getFilters());
		},
		onSearch: function () {
			this.getOrders(this.getFilters());
		},
		getFilters: function () {
			var filters = [];
			var that = this;
			if (this.getView().byId("orderNo").getValue() !== "") {
				filters.push(this._createFilter("orderNo", this.getView().byId("orderNo").getValue()));
			}
			if (this.getView().byId("month").getSelectedKey() !== "") {
				filters.push(this._createFilter("jobPeriod", this.getView().byId("month").getSelectedKey()));
			}
				
			if(this.getView().byId("year").getTokens().length > 0){
				jQuery.each(this.getView().byId("year").getTokens(), function (i, oInput) {
					filters.push(that._createFilter("jobYear", oInput.getKey()));
				});	
			}

			if (this.getView().byId("vendorCode").getValue() !== "") {
				filters.push(this._createFilter("vendorCode", this.getView().byId("vendorCode").getValue().toUpperCase()));
			}
			
			jQuery.each(this.byId("statusCombo").getSelectedKeys(), function (i, oInput) {
				filters.push(that._createFilter("status", oInput.toUpperCase()));
			});
			return filters;
		},
		
		userCreatedToken: function(oEvent) {
			var oMultiInput = sap.ui.getCore().byId(oEvent.getSource().getId());
			var _newTokens = [];
			_newTokens = new sap.m.Token({
				text: oEvent.getSource().getValue(),
				key: oEvent.getSource().getValue()
			});
			oMultiInput.addToken(_newTokens);
			oMultiInput.setValue();
		},
		
		//  *****  Get the Work Order List for Home Page  ****** //      
		getOrders: function (filters) {
			//var that = this;
			this.getView().byId("table").setBusy(true);
			var orderListTable = this.getView().byId("table");
			orderListTable.removeSelections();
			// orderListTable.bindItems({
			// 		path: "/OrderListSet",
			// 		template: orderListTable.getBindingInfo("items").template,
			// 		filters: null
			// 	});
			var oBinding = orderListTable.getBinding("items");
			oBinding.filter(null);
			oBinding.filter(filters);
			this.getView().byId("table").setBusy(false);
			// oModel.read("/OrderListSet", {
			// 	filters: filters,
			// 	success: function (oData, response) {
			// 		var orderListTable = that.getView().byId("table");
			// 		var jsonModel = new JSONModel();
			// 		jsonModel.setData({
			// 			orderListSet: oData.results
			// 		});
			// 		orderListTable.setModel(jsonModel);
			// 	}
			// });
		},

		// ***** Apply filter for Table rows *****  //		
		filterGlobally: function (oEvent) {
			var sQuery = oEvent.getParameter("query");
			this._oGlobalFilter = null;

			if (sQuery) {
				this._oGlobalFilter = new Filter([
					new Filter("orderNo", FilterOperator.Contains, sQuery),
					new Filter("vendorName", FilterOperator.Contains, sQuery),
					new Filter("vendorCode", FilterOperator.Contains, sQuery)
				], false);
			}

			this._filter();

			// this._mFilters = {
			// 	"orderNo": [new sap.ui.model.Filter("orderNo", "Contains", sQuery)],
			// 	"vendorName": [new sap.ui.model.Filter("vendorName", "Contains", sQuery)],
			// 	"vendorCode": [new sap.ui.model.Filter("vendorCode", "Contains", sQuery)]

			// };
			// var oBinding =this.getView().byId("table"),
			// sKey = "orderNo"; //oEvent.getParameter("selectedKey");
			// oBinding.filter(this._mFilters[sKey]);

		},
		_filter: function () {
			var oFilter = null;
			if (this._oGlobalFilter) {
				oFilter = this._oGlobalFilter;
			}
			this.getView().byId("table").getBinding("items").filter(oFilter, "Application");
		},

		//    **** Navigate to Detail Page of Materials  ****  //
		goToDetailSection: function (oEvent) {
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("DetailSection", {
				orderNo: oEvent.getSource().getBindingContext().getProperty("orderNo"),
				jobPeriodYear: oEvent.getSource().getBindingContext().getProperty("jobPeriod") + "-" + oEvent.getSource().getBindingContext().getProperty(
					"jobYear"),
				requesterId: oEvent.getSource().getBindingContext().getProperty("requesterId"),	
			}, true);
		},

		//     *** Open Dialg before confirmation of Batch Submit  **** //		
		_submitData: function (oEvent) {
			this.type = oEvent.getSource().getType();
			this.clickBtn = oEvent.getSource();
			var type = oEvent.getSource().getType();
			var that = this;
			var oDialog = new Dialog({
				title: "Confirm",
				type: "Message",
				content: [
					new sap.m.Label({
						text: "Please Add a Remarks",
						labelFor: "submitDialogTextarea"
					}),
					new sap.m.TextArea("submitDialogTextarea", {
						liveChange: function (event) {
							var sText = event.getParameter("value");
							var parent = event.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: "100%",
						placeholder: "Add note (required)"
					})
				],
				beginButton: new sap.m.Button({
					type: type,
					text: "Submit",
					enabled: false,
					press: function () {
						var remarksText = sap.ui.getCore().byId("submitDialogTextarea").getValue();
						that._submitFinalRemarks(remarksText, that);
						oDialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});
			oDialog.open();
		},

		//	 ****  Approve Or Reject by Multiple selection using Batch  **** //	 
		/* eslint-disable */
		_submitFinalRemarks: function (remarks, that) {
			//console.log(remarks);
			var status = "";
			var data = {};
			var oViewTable = that.getView().byId("table");
			if (that.type === "Accept")
				status = "APPROVED";
			else if (that.type === "Reject")
				status = "REJECTED";

			var tableData = this.getView().byId("table").getSelectedItems();
			var filters = [];
			
			for (var j = 0; j < tableData.length; j++) {
				if (tableData[j].getBindingContext().getProperty("status") === "APPROVED" || tableData[j].getBindingContext().getProperty("status") === "REJECTED") {
					this.openMessageBox().error("Order Number-" + tableData[j].getBindingContext().getProperty("orderNo") +
						" already "+ tableData[j].getBindingContext().getProperty("status").toLowerCase() +" for the period = " + formatter.jobMonth(tableData[j].getBindingContext().getProperty("jobPeriod"), tableData[
							j].getBindingContext().getProperty("jobYear")) +"\n Please Uncheck the record");
					return false;
				}
				filters.push(this._createFilter("orderNo", tableData[j].getBindingContext().getProperty("orderNo")));
				filters.push(this._createFilter("jobPeriod", tableData[j].getBindingContext().getProperty("jobPeriod")));
				filters.push(this._createFilter("jobYear", tableData[j].getBindingContext().getProperty("jobYear")));
				filters.push(this._createFilter("requesterId", tableData[j].getBindingContext().getProperty("requesterId")));

			}
			//return false;
			filters.push(this._createFilter("status", "PENDING"));

			sap.ui.core.BusyIndicator.show();
			oModel.read("/DetailTableSet", {
				filters: filters,
				urlParameters: {
					"$select": "orderNo,jobPeriod,jobYear,requesterId,materialNo,status"
				},
				success: function (oData, response) {
					//var jsonModel = new JSONModel();
					var results = oData.results;
					var aDeferredGroup = oModel.getDeferredGroups().concat("update");
					oModel.setDeferredGroups(aDeferredGroup);
					oModel.setUseBatch(true);
					var mParameters = {
						groupId: "update"
					};

					for (var i = 0; i < results.length; i++) {
						data = {
							orderNo: results[i].orderNo,
							jobPeriod: results[i].jobPeriod,
							jobYear: results[i].jobYear,
							materialNo: results[i].materialNo,
							status: status,
							remarks: remarks
						};
						oModel.sDefaultUpdateMethod = "MERGE";
						sap.ui.core.BusyIndicator.show();
						oModel.update("/CumulativeQtySet(orderNo='" + results[i].orderNo + "',jobPeriod='" + results[i].jobPeriod + "',jobYear='" +
							results[i].jobYear +
							"',materialNo='" + results[i].materialNo + "',requesterId='"+ results[i].requesterId +"')", data, mParameters);

					}
					oModel.submitChanges({
						success: function (oData, response) {
							//console.log(response);
							var responseArr = "";
							var data2 = {};
							var aMockMessages = [];
							var aMockMessages2 = "";
							if (typeof (oData.__batchResponses[0].__changeResponses) === "undefined") {
								/*  Error Response is 500||503  */
								responseArr = oData.__batchResponses[0];
								data2.type = "Error";
								data2.title = JSON.parse(responseArr.response.body).error.message.value;
								aMockMessages2 = aMockMessages2 + "Order no -"+ responseArr.orderNo + "has an Error" + "\n ";
								aMockMessages.push(data2);
							} else {
								responseArr = oData.__batchResponses[0].__changeResponses;
								for (var j = 0; j < responseArr.length; j++) {
									if (responseArr[j].statusCode === "200" || responseArr[j].statusCode === "201" || responseArr[j].statusCode === "202" ||
										responseArr[j].statusCode === "203" || responseArr[j].statusCode === "204") {
										data2.type = "Success";
										data2.title = JSON.parse(responseArr[j].headers["sap-message"]).message;
										//aMockMessages2 = aMockMessages2 + JSON.parse(responseArr[j].headers["sap-message"]).message + "\n ";
									}
									aMockMessages.push(data2);
								}
								
								for (j = 0; j < tableData.length; j++) {
									aMockMessages2 = aMockMessages2 + "Work Order- "+ tableData[j].getBindingContext().getProperty("orderNo") + " has been "+ status +" \n";
								}
							}
							//that.openMessagePopover(aMockMessages, that.clickBtn);
							if (data2.type === "Success") {
								that.openMessageBox().success(aMockMessages2);
								oViewTable.getBinding("items").refresh();
								oViewTable.removeSelections();
							} else {
								that.openMessageBox().error(aMockMessages2);
							}
							sap.ui.core.BusyIndicator.hide();
						},
						error: function (e) {
							//console.log(e);
							sap.ui.core.BusyIndicator.hide();
						}
					});

				}
			});
		},
		/* eslint-enable */

		//  **** Common function for create fitler object  ***** //		
		_createFilter: function (path, value) {
			return new sap.ui.model.Filter({
				path: path,
				operator: sap.ui.model.FilterOperator.EQ,
				value1: value
			});
		}
	});
});