sap.ui.define([], function () {
	"use strict";
	return {
		jobMonth: function (JobPeriod, JobYear) {
			switch (JobPeriod) {
			case "01":
				return "January '" + JobYear;
			case "1":
				return "January '" + JobYear;
			case "02":
				return "February '" + JobYear;
			case "2":
				return "February '" + JobYear;
			case "03":
				return "March '" + JobYear;
			case "3":
				return "March '" + JobYear;
			case "04":
				return "April '" + JobYear;
			case "4":
				return "April '" + JobYear;
			case "05":
				return "May '" + JobYear;
			case "5":
				return "May '" + JobYear;
			case "06":
				return "June '" + JobYear;
			case "6":
				return "June '" + JobYear;
			case "07":
				return "July '" + JobYear;
			case "7":
				return "July '" + JobYear;
			case "08":
				return "August '" + JobYear;
			case "8":
				return "August '" + JobYear;
			case "09":
				return "September '" + JobYear;
			case "9":
				return "September '" + JobYear;
			case "10":
				return "October '" + JobYear;
			case "11":
				return "November '" + JobYear;
			case "12":
				return "December '" + JobYear;
			default:
				return JobPeriod + " '" + JobYear;
			}
		},
		setState: function (status) {
			switch (status) {
			case "APPROVED":
				return "Success";
			case "PENDING":
				return "Warning";
			case "REJECTED":
				return "Error";
			default:
				return "None";
			}

		},
		setStateIcon: function (status) {
			switch (status) {
			case "APPROVED":
				return "sap-icon://accept";
			case "PENDING":
				return "sap-icon://pending";
			case "REJECTED":
				return "sap-icon://decline";
			default:
				return "";
			}
		},
		monthSet: function () {
			return {
				"CountriesCollection": [{
					"key": 1,
					"text": "01-January"
				}, {
					"key": 2,
					"text": "02-February"
				}, {
					"key": 3,
					"text": "03-March"
				}, {
					"key": 4,
					"text": "04-April"
				}, {
					"key": 5,
					"text": "05-May"
				}, {
					"key": 6,
					"text": "06-June"
				}, {
					"key": 7,
					"text": "07-July"
				}, {
					"key": 8,
					"text": "08-August"
				}, {
					"key": 9,
					"text": "09-September"
				}, {
					"key": 10,
					"text": "10-October"
				}, {
					"key": 11,
					"text": "11-November"
				}, {
					"key": 12,
					"text": "12-December"
				}]
			};

		},
		deviceType: function () {
			return sap.ui.Device.system.desktop;
		},
		wrapText: function (remarks) {
			if(sap.ui.Device.system.desktop && remarks.length > 0){
				return remarks.substring(0, 20) + "...";
			}
			if(sap.ui.Device.system.phone && remarks.length > 0){
				return remarks.substring(0, 30) + "...";
			}
		}
	};
});