sap.ui.define([
	"com/tatasteel/ZMM_MATRCON_APR/test/unit/controller/Home.controller"
], function () {
	"use strict";
});